<template>
	<view class="content">
		<view class="text1">
			<view class="text">
				<text space='emsp'>{{'  '}}亲爱的新同学，恭喜您即将步入大学殿堂，步入人生新的阶段，开启新的篇章！当您带着期盼步入美丽的大学校园，开启丰富多彩的大学生活时，预防身边的各种安全问题同样是不可忽视的。</text>
			</view>
			<view >
				<text class="title">新冠疫情下入学前防护指南 </text>
				<view class="blank"></view>
				<image class="picture" src="/static/matters/matters_a.webp"></image>
				<!-- <image src="/static/matters/matters_a.webp"></image> -->
			</view>
			<view >
				<text class="text" space="emsp">{{'  '}}入学报到前自备一次性医用口罩、温度计、一次性手套等防护用品，并在到校途中做好个人防护和自我健康监测。\n{{'  '}}入学健康状况申报。报到前确保身体状况良好，入学时根据学校统一要求提供个人健康申报证明材料。\n{{'  '}}加强自我防护，做好科学预防。自觉践行“须警惕、不轻视；少出门、少聚集；勤洗手、勤通风；戴口罩、讲卫生；打喷嚏、捂口鼻；喷嚏后、慎揉眼；有症状、早就医；不恐慌、不传谣”的防范守则。</text>
			</view>
			<view >
				<text class="title">报到安全须知 </text>
				<view class="blank"></view>
				<image class="picture" src="/static/matters/matters_c.png"></image>
			</view>
			<view class="text">
				<text space="emsp" style="color: crimson;">{{'  '}}*</text>
				<text space="emsp">新生报到时携带入学通知书、身份证、银行卡等各项入学所需材料。</text>
				<text space="emsp" style="color: crimson;">\n{{'  '}}*</text>
				<text space="emsp">贵重物品需随身携带，不要让陌生人代管。</text>
				<text space="emsp" style="color: crimson;">\n{{'  '}}*</text>
				<text space="emsp">各种入学手续要由本人或家属直接办理，不要委托他人代办，防止钱财被骗。</text>
				<text space="emsp"style="color: crimson;">\n{{'  '}}*</text>
				<text space="emsp">报到现场人员复杂，注意礼让，避免与他人发生口角、争执，造成人身伤害。</text>
				<text space="emsp"style="color: crimson;">\n{{'  '}}*</text>
				<text space="emsp">报到期间，进出寝室人员复杂，贵重物品随身携带。无人监管时要锁入寝室柜子，离开寝室时及时锁门。</text>
				<text space="emsp"style="color: crimson;">\n{{'  '}}*</text>
				<text space="emsp">及时把学校辅导员老师联系方式告诉家长，一旦发生情况能使家长与学校在第一时间沟通联系。</text>
				</view>
			<view  >
				<text class="title">警惕校园贷</text>	
				<view class="blank"></view>
				<image class="picture" src="/static/matters/matters_b.jpg"></image>
			</view>
			<view class="text">
				<text  space="emsp"> {{'  '}}校园贷指一些网络贷款平台面向在校大学生开展的贷款业务。在校学生只需网上提交资料、通过审核、支付一定手续费，就能轻松申请信用贷款。根据最高法院规定，借贷双方约定年利率未超过24%,应予支持;借贷双方约定利率在24%-36%系自然债区。若借贷双方约定利率超过36%，则定为高利贷，不予支持。</text>
				<text  space="emsp" style="font-weight: bold;" >\n{{'  '}}裸条贷 </text>
				<text  space="emsp">{{' '}}不法债主通过要挟借贷者以裸照或不雅视频作为贷款抵押证据的行为。</text>
				<text  space="emsp" style="font-weight: bold;">\n{{'  '}}传销贷</text>
				<text  space="emsp">{{' '}}不法分子借助校园贷款平台招慕大学生作为校园代理并要求发展学生下线进行逐级敛财。采用各种手段讨债一些放贷人进行放贷时会要求提供一定价值的物品进行抵押，而且要收取学生的学生证、身份证复印件，一旦学生不能按时还贷，放贷人可能会采取恐吓、殴打、威胁学生甚至其父母的手段进行暴力讨债，对学生的人身安全和高校的校园秩序造成重大危害。</text>
			</view>
			<view>
				<text class="title">自我情绪调节</text>
				<view class="blank"></view>
				<image class="picture" src="/static/matters/matters_d.png"></image>
			</view>
			<view class="text">
				<text  space='emsp'>{{'  '}}对于刚进校门的大学生来说，在适应大学环境的过程中，常会出现情绪的应激变化。如今，社会对大学生的期待颇高，大学生的心理压力大，学习负担重，竞争激烈，这些都很容易使大学生的心理处于紧张状态，情绪问题如果得不到正确处理，可能会引发更加严重的后果。</text>
			<view>
				<text  class="title2" space="emsp">{{'  '}}摆脱消极情绪的做法</text>
			</view class="text">
				<text  space="emsp">{{'  '}}暗示调节。即通过内在语言来提醒和安慰自己，如提醒自己“不要灰心”、“不要着急”、“一切都会过去的”、“事情并不像我相象的那么糟”等等，以此来缓解心理的压力，调整不良的情绪。\n{{'  '}}想象调节。是指在想象中对现实生活里的挫折情境、自己感到紧张、焦虑的事件进行预演，学会在想象的情境中放松自己，并使之迁移，达到能在真实的处境中处理各种不良心态的情绪反应。\n{{'  '}}多沟通。遇到烦心事多与同学、老师和家长沟通，寻求帮助。</text>
			</view>
		</view>
	</view>
</template>

<script>
	import globalSetting from '@/common/json/globalSetting.json';
	export default {
		onPullDownRefresh() {		//下拉刷新函数，处理回弹
			console.log('refresh');
			setTimeout(function () {
				uni.stopPullDownRefresh();
			}, 1000);
		},
	}
</script>

<style>
	.picture{
		margin-top: 50rpx;
		width: 600rpx;
		margin: auto;
		margin-left: 25rpx;
		outline-style: groove;
		outline-color: #5555ff;
		outline-width: 10rpx;
	},
	.blank{
		width: 50rpx;
		height: 50rpx;
	}
	.title{
		font-size: 50rpx;
		display: flex;
		flex-direction: column-reverse;
		align-items: center;
		justify-content: center;
		font-weight: bold;
		margin-top: 50rpx;
	}
	.title2{
				font-size: 45rpx;
				font-weight: bold;
	}
	.text1{
		margin-top: 50rpx;
		color: #000000;
		width: 650rpx;
		background-color: #ffffff;
	}
	.content{
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}
	.text{
		font-size: 38rpx;
	}
</style>
